﻿using MailKit.Net.Smtp;
using Microsoft.Extensions.Options;
using MimeKit;
using System.Text.RegularExpressions;

namespace MiddleManagement.Services
{
    public class EmailSmsService : ISmsService
    {
        private readonly EmailConfig _config;

        public EmailSmsService(IOptions<EmailConfig> config)
        {
            _config = config.Value;
        }

        public async Task Send(string? targetPhoneNumber)
        {
            if (string.IsNullOrEmpty(targetPhoneNumber))
            {
                throw new ArgumentNullException(nameof(targetPhoneNumber));
            }

            var phoneNumber = targetPhoneNumber;
            var fromEmailAddress = _config.FromEmailAddress;
            var phoneNumberDigits = Regex.Matches(phoneNumber, "\\d+").Select(x => x.ToString()).ToInlineString();
            var email = $"{phoneNumberDigits}@{_config.EmailDomain}";

            var mailMessage = new MimeMessage();
            mailMessage.From.Add(new MailboxAddress(_config.FromEmailAddressName, fromEmailAddress));
            mailMessage.To.Add(new MailboxAddress(phoneNumber, email));
            mailMessage.Subject = _config.Subject;
            mailMessage.Body = new TextPart("plain")
            {
                Text = string.Format(_config.BodyFormat, _config.SurveyUrl)
            };

            using SmtpClient smtpClient = new();
            await smtpClient.ConnectAsync(_config.SmtpServer, _config.SmtpPort, _config.SmtpSocketOptions);
            await smtpClient.AuthenticateAsync(_config.FromEmailAddress?.Split('@')[0], _config.FromEmailPassword);
            await smtpClient.SendAsync(mailMessage);
            await smtpClient.DisconnectAsync(true);
        }
    }
}
