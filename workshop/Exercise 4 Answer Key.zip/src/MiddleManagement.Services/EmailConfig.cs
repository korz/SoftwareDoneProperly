﻿using MailKit.Security;

namespace MiddleManagement.Services
{
    public class EmailConfig
    {
        public string? FromEmailAddress { get; set; }
        public string? FromEmailPassword { get; set; }

        public string FromEmailAddressName { get; set; } = "Software Done Properly";
        public string EmailDomain { get; set; } = "txt.att.net";
        public string SurveyUrl { get; set; } = "http://localhost:5227/";
        public string Subject { get; set; } = "Time to Take Survey";
        public string BodyFormat { get; set; } = "Your survey is ready, visit {0} to complete.";

        public string SmtpServer { get; set; } = "smtp.gmail.com";
        public int SmtpPort { get; set; } = 587;
        public SecureSocketOptions SmtpSocketOptions { get; set; } = SecureSocketOptions.StartTls;
    }
}
