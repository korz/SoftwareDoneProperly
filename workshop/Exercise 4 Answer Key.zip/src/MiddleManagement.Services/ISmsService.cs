﻿namespace MiddleManagement.Services
{
    public interface ISmsService
    {
        Task Send(string? targetPhoneNumber);
    }
}
