﻿using System.Text;

namespace MiddleManagement.Services
{
    public static class Extensions
    {
        public static string ToInlineString(this IEnumerable<string> texts)
        {
            var stringBuilder = new StringBuilder();

            foreach (var text in texts)
            {
                stringBuilder.Append(text);
            }

            return stringBuilder.ToString();
        }
    }
}
