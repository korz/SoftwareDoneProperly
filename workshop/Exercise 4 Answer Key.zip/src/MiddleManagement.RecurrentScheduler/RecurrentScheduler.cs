﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace MiddleManagement.RecurrentScheduler
{
    public abstract class RecurrentScheduler : BackgroundService
    {
        protected readonly IRecurrentSchedulerConfig _config;
        private Timer? _timer;

        public RecurrentScheduler(IOptions<IRecurrentSchedulerConfig> config)
        {
            _config = config.Value;
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            stoppingToken.ThrowIfCancellationRequested();

            _timer = new Timer(RunTimer, null, TimeSpan.Zero, TimeSpan.FromMinutes(_config.IntervalBetweenSendsInMinutes));

            return Task.CompletedTask;
        }

        private void RunTimer(object? state)
        {
            RunTimerAsync().Wait();
        }

        protected abstract Task RunTimerAsync();
    }
}
