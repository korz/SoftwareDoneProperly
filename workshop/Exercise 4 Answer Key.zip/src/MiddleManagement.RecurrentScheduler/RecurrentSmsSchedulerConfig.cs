﻿namespace MiddleManagement.RecurrentScheduler
{
    public class RecurrentSmsSchedulerConfig : IRecurrentSchedulerConfig
    {
        public int IntervalBetweenSendsInMinutes { get; set; } = 5;
        public string? TargetPhoneNumber { get; set; }
    }
}
