﻿namespace MiddleManagement.RecurrentScheduler
{
    public interface IRecurrentSchedulerConfig
    {
        int IntervalBetweenSendsInMinutes { get; set; }
    }
}
