﻿using Microsoft.Extensions.Options;
using MiddleManagement.Services;

namespace MiddleManagement.RecurrentScheduler
{
    public class RecurrentSmsScheduler : RecurrentScheduler
    {
        private readonly ISmsService _smsService;

        public RecurrentSmsScheduler(ISmsService smsService, IOptions<RecurrentSmsSchedulerConfig> config) : base(config)
        {
            _smsService = smsService;
        }

        protected override async Task RunTimerAsync()
        {
            await _smsService.Send((base._config as RecurrentSmsSchedulerConfig)!.TargetPhoneNumber);
        }
    }
}