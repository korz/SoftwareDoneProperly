﻿using System.Text;

namespace MiddleManagement.Core
{
    public static class StringExtensions
    {
        public static string ToInlineString(this IEnumerable<string> texts)
        {
            var stringBuilder = new StringBuilder();

            foreach (var text in texts)
            {
                stringBuilder.Append(text);
            }

            return stringBuilder.ToString();
        }
    }
}
