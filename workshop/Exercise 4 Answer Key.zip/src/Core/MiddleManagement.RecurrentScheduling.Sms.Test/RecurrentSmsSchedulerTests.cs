using Microsoft.Extensions.Options;
using MiddleManagement.Emailing;
using MiddleManagement.RecurrentScheduling.Sms;
using Moq;
using NUnit.Framework;

namespace MiddleManagement.UnitTests
{
    public class RecurrentSmsSchedulerTests
    {
        [Test]
        public async Task RunTimerAsync()
        {
            var mockSmsService = new Mock<ISmsService>();
            var mockOptions = Options.Create(new RecurrentSmsSchedulerConfig()
            {
                IntervalBetweenSendsInMinutes = 60,
                SmsText = "Time to take the survey",
                TargetPhoneNumber = "5555555555"
            });

            mockSmsService.Setup(x => x.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);

            var scheduler = new RecurrentSmsScheduler(mockSmsService.Object, mockOptions);
            await scheduler.RunTimerAsync();

            mockSmsService.Verify(x => x.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }
    }
}