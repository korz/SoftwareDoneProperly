﻿using Microsoft.Extensions.Options;
using MiddleManagement.Sms;

namespace MiddleManagement.RecurrentScheduling.Sms
{
    public class RecurrentSmsScheduler : RecurrentScheduler, IRecurrentScheduler
    {
        private readonly ISmsService _smsService;

        public RecurrentSmsScheduler(ISmsService smsService, IOptions<RecurrentSmsSchedulerConfig> config) : base(config)
        {
            _smsService = smsService;
        }

        public override async Task RunTimerAsync()
        {
            var config = base._config as RecurrentSmsSchedulerConfig;
            await _smsService.SendSmsAsync(config!.SmsText, config!.TargetPhoneNumber);
        }
    }
}
