﻿namespace MiddleManagement.RecurrentScheduling.Sms
{
    public class RecurrentSmsSchedulerConfig : IRecurrentSchedulerConfig
    {
        public int IntervalBetweenSendsInMinutes { get; set; } = 5;
        public string SmsText { get; set; }
        public string? TargetPhoneNumber { get; set; }
    }
}
