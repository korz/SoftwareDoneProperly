﻿namespace MiddleManagement.Sms
{
    public interface ISmsService
    {
        Task SendSmsAsync(string smsText, string phoneNumber);
    }
}