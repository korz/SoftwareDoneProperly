﻿using System.Text.RegularExpressions;
using Microsoft.Extensions.Options;
using MimeKit;
using MailKit.Net.Smtp;
using MiddleManagement.Core;

namespace MiddleManagement.Sms
{
    public class EmailSmsService : ISmsService
    {
        public EmailConfig? EmailOptions { get; private set; }

        public EmailSmsService(IOptions<EmailConfig> emailOptions)
        {
            EmailOptions = emailOptions.Value;
        }

        public async Task SendSmsAsync(string smsText, string phoneNumber)
        {
            if (EmailOptions == null)
            {
                throw new InvalidOperationException("You must run SmsSender.SetupOptions() before attempting to send SMS.");
            }

            string? fromEmailAddress = EmailOptions.FromEmailAddress;

            if (string.IsNullOrEmpty(fromEmailAddress))
            {
                throw new InvalidOperationException("FromEmailAddress has a null, empty, or whitespace string as its value. A proper email address must be provided.");
            }

            string? phoneNumberDigits = Regex.Matches(phoneNumber, "\\d+").Select(x => x.ToString()).ToInlineString();
            string? email = $"{phoneNumberDigits}@{EmailOptions.EmailDomain}";
            MimeMessage? mailMessage = new();
            mailMessage.From.Add(new MailboxAddress(EmailOptions.FromEmailAddressName, fromEmailAddress));
            mailMessage.To.Add(new MailboxAddress(phoneNumber, email));
            mailMessage.Subject = EmailOptions.Subject;
            mailMessage.Body = new TextPart("plain") { Text = smsText };
            using (SmtpClient? smtpClient = new SmtpClient())
            {
                await smtpClient.ConnectAsync(EmailOptions.SmtpServer, EmailOptions.SmtpPort, EmailOptions.SmtpSocketOptions);
                await smtpClient.AuthenticateAsync(fromEmailAddress.Split('@')[0], EmailOptions.FromEmailPassword);
                await smtpClient.SendAsync(mailMessage);
                await smtpClient.DisconnectAsync(true);
            }
        }
    }
}
