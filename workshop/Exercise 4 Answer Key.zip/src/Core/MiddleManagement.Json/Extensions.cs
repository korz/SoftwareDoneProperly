﻿using Newtonsoft.Json;

namespace MiddleManagement.Json
{
    public static class Extensions
    {
        public static string ToJson<T>(this T instance)
        {
            return JsonConvert.SerializeObject(instance, Formatting.Indented);
        }
    }
}
