﻿namespace MiddleManagement.Emailing
{
    public interface ISmsService
    {
        Task SendSmsAsync(string smsText, string phoneNumber);
    }
}