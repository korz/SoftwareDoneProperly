﻿namespace MiddleManagement.RecurrentScheduling
{
    public interface IRecurrentScheduler
    {
        Task RunTimerAsync();
    }
}
