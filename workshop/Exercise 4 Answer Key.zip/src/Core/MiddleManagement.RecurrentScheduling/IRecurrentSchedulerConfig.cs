﻿namespace MiddleManagement.RecurrentScheduling
{
    public interface IRecurrentSchedulerConfig
    {
        int IntervalBetweenSendsInMinutes { get; set; }
    }
}
