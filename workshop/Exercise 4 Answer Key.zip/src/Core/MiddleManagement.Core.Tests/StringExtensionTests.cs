﻿using NUnit.Framework;

namespace MiddleManagement.Core.Tests
{
    public class StringExtensionTests
    {
        [Test]
        public void ToInlineString()
        {
            var strings = new List<string> { "Hello", " ", "World", "!!!" };
            var expectedText = "Hello World!!!";
            var processedText = strings.ToInlineString();

            Assert.That(processedText, Is.EqualTo(expectedText));
        }
    }
}
