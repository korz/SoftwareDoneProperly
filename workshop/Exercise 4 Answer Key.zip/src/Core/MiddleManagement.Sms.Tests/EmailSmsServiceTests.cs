﻿using Microsoft.Extensions.Options;

namespace MiddleManagement.Sms.Tests
{
    public class EmailSmsServiceTests
    {
        [Test]
        public void SendSmsAsync_WithNullOptions_ShouldThrowError()
        {
            var emailSmsService = new EmailSmsService(Options.Create<EmailConfig>(null));

            Assert.ThrowsAsync<InvalidOperationException>(() => emailSmsService.SendSmsAsync("Survey's Ready", "5558883333"));
        }
    }
}
