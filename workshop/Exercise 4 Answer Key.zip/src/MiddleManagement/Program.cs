using MiddleManagement.Sms;
using MiddleManagement.FileSystemAbstractions;
using MiddleManagement.Options;
using MiddleManagement.RecurrentScheduling;
using MiddleManagement.RecurrentScheduling.Sms;
using MiddleManagement.Services;

namespace MiddleManagement
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            builder.Configuration
                   .SetBasePath(builder.Environment.ContentRootPath)
                   .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                   .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true)
                   .AddEnvironmentVariables();

            builder.Services.AddOptions<EmailConfig>().BindConfiguration("EmailOptions");
            builder.Services.AddOptions<SurveySenderConfig>().BindConfiguration("SenderOptions");
            builder.Services.AddOptions<ApplicationConfig>().BindConfiguration("ApplicationOptions");

            builder.Services.AddHostedService<RegularSurveySenderService>();

            builder.Services.AddSingleton<ISmsService, EmailSmsService>();
            builder.Services.AddSingleton<IFileSystem, DiskFileSystem>();
            builder.Services.AddSingleton<IRecurrentScheduler, RecurrentSmsScheduler>();

            builder.Services.AddLogging();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
