﻿using Microsoft.Extensions.Options;
using MiddleManagement.Options;
using MiddleManagement.Sms;

namespace MiddleManagement.Services
{
    public class RegularSurveySenderService : BackgroundService
    {
        private readonly SurveySenderConfig _senderConfig;
        private readonly ISmsService _smsService;
        private Timer? _timer;

        public RegularSurveySenderService(IOptions<SurveySenderConfig> senderConfig,
                                          ISmsService smsService)
        {
            _senderConfig = senderConfig.Value;
            _smsService = smsService;
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            stoppingToken.ThrowIfCancellationRequested();

            _timer = new Timer(RunTimer, null, TimeSpan.Zero, TimeSpan.FromMinutes(_senderConfig.IntervalBetweenSendsInMinutes));

            return Task.CompletedTask;
        }

        private void RunTimer(object? state)
        {
            RunTimerAsync().Wait();
        }

        private async Task RunTimerAsync()
        {
            string? surveyUrl = "http://localhost:5227/";
            string? phoneNumber = _senderConfig.TargetPhoneNumber;
            await _smsService.SendSmsAsync($"Your survey is ready, visit {surveyUrl} to complete.", phoneNumber);
        }
    }
}
