﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MiddleManagement.Models;
using MiddleManagement.Options;
using System.Diagnostics;
using MiddleManagement.FileSystemAbstractions;
using MiddleManagement.Sms;

namespace MiddleManagement.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationConfig _appConfig;
        private readonly ISmsService _smsService;
        private readonly IFileSystem _fileSystem;

        public HomeController(ILogger<HomeController> logger,
                              ISmsService smsService,
                              IOptions<ApplicationConfig> appConfig,
                              IFileSystem fileSystem)
        {
            _logger = logger;
            _appConfig = appConfig.Value;
            _smsService = smsService;
            _fileSystem = fileSystem;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View(new IndexModel());
        }

        [HttpPost]
        public async Task<IActionResult> Index([Bind] IndexModel model)
        {
            if (ModelState.IsValid)
            {
                model.Timestamp = DateTime.Now;

                string? resultsFilename = $"{_appConfig.ResultsFilePath}/{model.Timestamp:yyyy_MM_dd_hh_mm_ss}.txt";

                await _fileSystem.SaveObjectToJsonFileAsync(resultsFilename, model);
            }

            return View(model);
        }

        public async Task<IActionResult> SendSurveySms(string phoneNumber)
        {
            string? surveyUrl = "http://localhost:5227/";
            await _smsService.SendSmsAsync($"Your survey is ready, visit {surveyUrl} to complete.", phoneNumber);

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
