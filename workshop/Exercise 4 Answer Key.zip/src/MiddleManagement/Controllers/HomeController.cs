﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MiddleManagement.Models;
using MiddleManagement.Options;
using MiddleManagement.Services;
using System.Diagnostics;

namespace MiddleManagement.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> Logger;
        private readonly ISmsService SmsService;
        private readonly ApplicationConfig AppConfig;

        public HomeController(ILogger<HomeController> logger,
                              ISmsService smsService,
                              IOptions<ApplicationConfig> appConfig)
        {
            Logger = logger;
            SmsService = smsService;
            AppConfig = appConfig.Value;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View(new IndexModel());
        }

        [HttpPost]
        public async Task<IActionResult> Index([Bind] IndexModel model)
        {
            if (ModelState.IsValid)
            {
                model.Timestamp = DateTime.Now;

                string? resultsFilename = $"{AppConfig.ResultsFilePath}/{DateTime.Now:yyyy_MM_dd_hh_mm_ss}.txt";

                await System.IO.File.WriteAllTextAsync(resultsFilename, model.ToJson());
            }

            return View(model);
        }

        public async Task<IActionResult> SendSurveySms(string phoneNumber)
        {
            await SmsService.Send(phoneNumber);

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
