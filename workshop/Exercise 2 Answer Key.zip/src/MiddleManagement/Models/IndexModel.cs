﻿using System.ComponentModel.DataAnnotations;

namespace MiddleManagement.Models
{
    public class IndexModel
    {
        public DateTime Timestamp { get; set; }

        [Required]
        [Range(1, 10)]
        public int FeelingScore { get; set; }

        [StringLength(300)]
        public string? Comments { get; set; }
    }
}
