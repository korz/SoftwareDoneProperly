﻿namespace MiddleManagement.Services
{
    public class EmailConfig
    {
        public string? FromEmailAddress { get; set; }
        public string? FromEmailPassword { get; set; }
    }
}
