﻿namespace MiddleManagement.Services
{
    public class DiskFileSystem : IFileSystem
    {
        public async Task SaveTextToFileAsync(string filename, string text)
        {
            await File.WriteAllTextAsync(filename, text);
        }

        public async Task SaveObjectToJsonFileAsync<T>(string filename, T instance)
        {
            await File.WriteAllTextAsync(filename, instance.ToJson());
        }
    }
}
