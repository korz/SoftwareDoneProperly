﻿namespace MiddleManagement.Services
{
    public interface IFileSystem
    {
        Task SaveTextToFileAsync(string filename, string text);
        Task SaveObjectToJsonFileAsync<T>(string filename, T instance);        
    }
}
