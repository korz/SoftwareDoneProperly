using MiddleManagement.Services;
using MiddleManagement.UnitTests.Contracts;

namespace MiddleManagement.UnitTests
{
    public class DiskFileSystemTests
    {
        private IFileSystem FileSystem;

        [SetUp]
        public async Task Setup()
        {
            FileSystem = new DiskFileSystem();

            var filenames = new List<string>
            {
                "SaveTextToFileAsync.txt",
                "SaveObjectToJsonFileAsync.txt"
            };

            filenames.ForEach(x => { if (File.Exists(x)) { File.Delete(x); } });
        }

        [TearDown]
        public async Task Teardown()
        {
            var filenames = new List<string>
            {
                "SaveTextToFileAsync.txt",
                "SaveObjectToJsonFileAsync.txt"
            };

            filenames.ForEach(x => { if (File.Exists(x)) { File.Delete(x); } });
        }

        [Test]
        public async Task SaveTextToFileAsync()
        {
            var filename = "SaveTextToFileAsync.txt";
            var text = "Hello World!!!";

            await FileSystem.SaveTextToFileAsync(filename, text);

            var savedText = await File.ReadAllTextAsync(filename);

            Assert.That(savedText, Is.EqualTo(text));
        }

        [Test]
        public async Task SaveObjectToJsonFileAsync()
        {
            var filename = "SaveObjectToJsonFileAsync.txt";

            var customer = new Customer
            {
                FirstName = "John",
                LastName = "Smith",
                Address = new Address
                {
                    Street = "123 Main Street",
                    City = "Royal Oak",
                    State = "MI",
                    Zip = "48005-1234"
                }
            };

            var expectedJson = @"{
  ""FirstName"": ""John"",
  ""LastName"": ""Smith"",
  ""Address"": {
    ""Street"": ""123 Main Street"",
    ""City"": ""Royal Oak"",
    ""State"": ""MI"",
    ""Zip"": ""48005-1234""
  }
}";

            await FileSystem.SaveObjectToJsonFileAsync(filename, customer);

            var savedJson = await File.ReadAllTextAsync(filename);

            Assert.That(savedJson, Is.EqualTo(expectedJson));
        }
    }
}