using MiddleManagement.Services;
using MiddleManagement.UnitTests.Contracts;

namespace MiddleManagement.UnitTests
{
    public class ServiceExtensionTests
    {
        [Test]
        public void ToInlineString()
        {
            var strings = new List<string> { "Hello", " ", "World", "!!!" };
            var expectedText = "Hello World!!!";
            var processedText = strings.ToInlineString();

            Assert.That(processedText, Is.EqualTo(expectedText));
        }

        [Test]
        public void ToJson()
        {
            var customer = new Customer
            {
                FirstName = "John",
                LastName = "Smith",
                Address = new Address
                {
                    Street = "123 Main Street",
                    City = "Royal Oak",
                    State = "MI",
                    Zip = "48005-1234"
                }
            };

            var expectedJson = @"{
  ""FirstName"": ""John"",
  ""LastName"": ""Smith"",
  ""Address"": {
    ""Street"": ""123 Main Street"",
    ""City"": ""Royal Oak"",
    ""State"": ""MI"",
    ""Zip"": ""48005-1234""
  }
}";

            var customerJson = customer.ToJson();

            Assert.That(customerJson, Is.EqualTo(expectedJson));
        }
    }
}
