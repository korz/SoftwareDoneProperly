using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MiddleManagement.Controllers;
using MiddleManagement.Models;
using MiddleManagement.Options;
using MiddleManagement.Services;

namespace MiddleManagement.UnitTests
{
    public class HomeControllerTests
    {
        [Test]
        public async Task Index_ForwardsSmsToService()
        {
            var mockLogger = new Mock<ILogger<HomeController>>();
            var mockSmsService = new Mock<ISmsService>();
            var mockOptions = new Mock<IOptions<ApplicationConfig>>();
            var newMockOptions = Microsoft.Extensions.Options.Options.Create(new ApplicationConfig()
            {
                ResultsFilePath = @"C:\myFile.txt"
            });

            var mockFileSystem = new Mock<IFileSystem>();

            mockSmsService.Setup(x => x.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);

            var controller = new HomeController(mockLogger.Object, mockSmsService.Object, newMockOptions, mockFileSystem.Object);
            var model = new IndexModel { Timestamp = DateTime.Now, FeelingScore = 100, Comments = "Woo Hoo!" };
            await controller.Index(model);

            mockFileSystem.Verify(x => x.SaveObjectToJsonFileAsync(It.IsAny<string>(), model), Times.Once);
        }

        [Test]
        public async Task Index_SendSmsSurvey_ForwardsSmsToService()
        {
            var mockLogger = new Mock<ILogger<HomeController>>();
            var mockSmsService = new Mock<ISmsService>();
            var mockOptions = new Mock<IOptions<ApplicationConfig>>();
            var mockFileSystem = new Mock<IFileSystem>();

            mockSmsService.Setup(x => x.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);

            var controller = new HomeController(mockLogger.Object, mockSmsService.Object, mockOptions.Object, mockFileSystem.Object);

            await controller.SendSurveySms("5558883333");

            mockSmsService.Verify(x => x.SendSmsAsync(It.IsAny<string>(), "5558883333"), Times.Once);
        }
    }
}