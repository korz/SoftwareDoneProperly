using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MiddleManagement.Controllers;
using MiddleManagement.Options;
using MiddleManagement.Services;

namespace MiddleManagement.UnitTests
{
    public class HomeControllerTests
    {
        [Test]
        public async Task Index_SendSmsSurvey_ForwardsSmsToService()
        {
            var mockLogger = new Mock<ILogger<HomeController>>();
            var mockSmsService = new Mock<ISmsService>();
            var mockOptions = new Mock<IOptions<ApplicationConfig>>();

            mockSmsService.Setup(x => x.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);

            var controller = new HomeController(mockLogger.Object, mockSmsService.Object, mockOptions.Object);

            await controller.SendSurveySms("5558883333");

            mockSmsService.Verify(x => x.SendSmsAsync(It.IsAny<string>(), "5558883333"), Times.Once);
        }
    }
}