﻿using Newtonsoft.Json;
using System.Text;

namespace MiddleManagement.Controllers
{
    public static class Extensions
    {
        public static string ToInlineString(this IEnumerable<string> texts)
        {
            var stringBuilder = new StringBuilder();

            foreach(var text in texts)
            {
                stringBuilder.Append(text);
            }

            return stringBuilder.ToString();
        }

        public static string ToJson<T>(this T instance)
        {
            return JsonConvert.SerializeObject(instance, Formatting.Indented);
        }
    }
}
