﻿using MailKit.Security;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Options;
using MiddleManagement.Options;
using MimeKit;
using MailKit.Net.Smtp;
using MiddleManagement.Controllers;

namespace MiddleManagement.Services
{
    public class RegularSurveySenderService : BackgroundService
    {
        private readonly SurveySenderConfig _senderConfig;
        private readonly EmailConfig _emailOptions;
        private Timer? _timer;

        public RegularSurveySenderService(IOptions<SurveySenderConfig> senderConfig,
                              IOptions<EmailConfig> emailOptions)
        {
            _senderConfig = senderConfig.Value;
            _emailOptions = emailOptions.Value;
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            stoppingToken.ThrowIfCancellationRequested();

            _timer = new Timer(RunTimer, null, TimeSpan.Zero, TimeSpan.FromMinutes(_senderConfig.IntervalBetweenSendsInMinutes));

            return Task.CompletedTask;
        }

        private void RunTimer(object? state)
        {
            RunTimerAsync().Wait();
        }

        private async Task RunTimerAsync()
        {
            var phoneNumber = _senderConfig.TargetPhoneNumber;
            var fromEmailAddress = _emailOptions.FromEmailAddress;
            var phoneNumberDigits = Regex.Matches(phoneNumber, "\\d+").Select(x => x.ToString()).ToInlineString();
            var email = $"{phoneNumberDigits}@txt.att.net";
            var surveyUrl = "http://localhost:5227/";

            var mailMessage = new MimeMessage();
            mailMessage.From.Add(new MailboxAddress("Software Done Properly", fromEmailAddress));
            mailMessage.To.Add(new MailboxAddress(phoneNumber, email));
            mailMessage.Subject = "Time to Take Survey";
            mailMessage.Body = new TextPart("plain")
            {
                Text = $"Your survey is ready, visit {surveyUrl} to complete."
            };

            using (var smtpClient = new SmtpClient())
            {
                await smtpClient.ConnectAsync("smtp.gmail.com", 587, SecureSocketOptions.StartTls);
                await smtpClient.AuthenticateAsync(_emailOptions.FromEmailAddress.Split('@')[0], _emailOptions.FromEmailPassword);
                await smtpClient.SendAsync(mailMessage);
                await smtpClient.DisconnectAsync(true);
            }
        }
    }
}
