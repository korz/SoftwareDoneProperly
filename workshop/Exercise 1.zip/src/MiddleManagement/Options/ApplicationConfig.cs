﻿namespace MiddleManagement.Options
{
    public class ApplicationConfig
    {
        public string? ResultsFilePath { get; set; }
    }
}
