﻿namespace MiddleManagement.Options
{
    public class EmailConfig
    {
        public string? FromEmailAddress { get; set; }
        public string? FromEmailPassword { get; set; }
    }
}
