﻿using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.AspNetCore.Mvc;
using MiddleManagement.Models;
using MimeKit;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace MiddleManagement.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View(new IndexModel());
        }

        [HttpPost]
        public async Task<IActionResult> Index([Bind] IndexModel model)
        {
            //TODO: Change to .Net 7.0

            if (ModelState.IsValid)
            {
                model.Timestamp = DateTime.Now;

                var resultsFilename = $"{Program.ResultsFilePath}/{DateTime.Now:yyyy_MM_DD_hh_mm_ss}.txt";

                await System.IO.File.WriteAllTextAsync(resultsFilename, model.ToJson());
            }

            return View(model);
        }

        public async Task<IActionResult> SendSurveySms(string phoneNumber)
        {
            var fromEmailAddress = "software.done.properly@gmail.com";
            var phoneNumberDigits = Regex.Matches(phoneNumber, "\\d+").Select(x => x.ToString()).ToInlineString();
            var email = $"{phoneNumberDigits}@txt.att.net";
            var surveyUrl = "http://localhost:5227/";

            var mailMessage = new MimeMessage();
            mailMessage.From.Add(new MailboxAddress("Software Done Properly", fromEmailAddress));
            mailMessage.To.Add(new MailboxAddress(phoneNumber, email));
            mailMessage.Subject = "Time to Take Survey";
            mailMessage.Body = new TextPart("plain")
            {
                Text = $"Your survey is ready, visit {surveyUrl} to complete."
            };

            using (var smtpClient = new SmtpClient())
            {
                await smtpClient.ConnectAsync("smtp.gmail.com", 587, SecureSocketOptions.StartTls);
                await smtpClient.AuthenticateAsync("software.done.properly", "fzduamibbjgwomey");
                await smtpClient.SendAsync(mailMessage);
                await smtpClient.DisconnectAsync(true);
            }

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
